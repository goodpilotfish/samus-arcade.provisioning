/*
 *
 *  Attract-Mode frontend
 *  Copyright (C) 2014 Andrew Mickelson
 *
 *  This file is part of Attract-Mode.
 *
 *  Attract-Mode is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Attract-Mode is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Attract-Mode.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef FE_UTIL_OSX_HPP
#define FE_UTIL_OSX_HPP

#include <string>
#include <SFML/Config.hpp>

//
// Hide the OS X menu bar.
//
void osx_hide_menu_bar();

//
// Get a string from the OS X clipboard.
//
std::basic_string<sf::Uint32> osx_clipboard_get_content();

//
// Put the focus on Attract-Mode.
//
void osx_take_focus();

#endif
